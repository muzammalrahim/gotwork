<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserSkillController extends Controller
{
    //
}
