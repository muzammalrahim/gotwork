<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectSkill extends Model
{
    use HasFactory;


    public function skillName()
    {
        return $this->belongsTo(Skill::class,'skill_id');
    }
}
