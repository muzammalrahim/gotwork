<header id="header-section" class="header active-three" style="
">

    	
 <!-- Start: Header Top
    ============================= -->
    <div id="header-top" class="header-above">
    	<div class="header-abover-mobile">
			<div class="header-above-button">
				<button type="button" class="pull-down-toggle"><i class="fa fa-chevron-down"></i></button>
			</div>
			<div id="mobi-above" class="mobi-above"><div class="container">
	            <div class="row">
	                <div class="col-lg-9 col-md-12 text-lg-left text-center my-auto mb-lg-0 mb-sm-3 mb-3">
	                    <ul class="header-info d-inline-block">
																															<li class="tlh-email"><a href="mailto:info@gotmework.com"><i class="fa fa-envelope-o"></i>info@gotmework.com</a></li>
									
																															<li class="tlh-faq"><a href="#"><i class="fa fa-wechat"></i>Ask Your Question</a></li>
																					
	                    </ul>
	                </div>
					
	                <div class="col-lg-3 col-md-12 text-lg-right text-center my-auto">
							                    <ul class="trh-social d-inline-block">
															<li><a href="#"><i class="fa fa-facebook "></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin "></i></a></li>
															<li><a href="#"><i class="fa fa-twitter "></i></a></li>
															<li><a href="#"><i class="fa fa-google-plus "></i></a></li>
								                    </ul>  
							                </div>
			     </div>
	        </div></div>
		</div>
		<div class="header-above-desk">
	        <div class="container">
	            <div class="row">
	                <div class="col-lg-9 col-md-12 text-lg-left text-center my-auto mb-lg-0 mb-sm-3 mb-3">
	                    <ul class="header-info d-inline-block">
																															<li class="tlh-email"><a href="mailto:info@gotmework.com"><i class="fa fa-envelope-o"></i>info@gotmework.com</a></li>
									
																															<li class="tlh-faq"><a href="#"><i class="fa fa-wechat"></i>Ask Your Question</a></li>
																					
	                    </ul>
	                </div>
					
	                <div class="col-lg-3 col-md-12 text-lg-right text-center my-auto">
							                    <ul class="trh-social d-inline-block">
															<li><a href="#"><i class="fa fa-facebook "></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin "></i></a></li>
															<li><a href="#"><i class="fa fa-twitter "></i></a></li>
															<li><a href="#"><i class="fa fa-google-plus "></i></a></li>
								                    </ul>  
							                </div>
			     </div>
	        </div>
	    </div>
    </div>
	
    	<div class="navigator-wrapper" style="min-height: 112px;">
    		<div class="theme-mobile-nav d-lg-none d-block sticky-nav">        
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="theme-mobile-menu">
								<div class="mobile-logo">
									<div class="logo">
			                            <a href="#">
											 </a><a href="https://gotmework.com/" class="custom-logo-link" rel="home" aria-current="page"><img width="1948" height="583" src="https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1.png" class="custom-logo" alt="Got Work" srcset="https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1.png 1948w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-300x90.png 300w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-1024x306.png 1024w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-768x230.png 768w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-1536x460.png 1536w" sizes="(max-width: 1948px) 100vw, 1948px"></a>																								<p class="site-description">Experts around the middle east</p>
																					
			                        </div>
								</div>		
								<div class="menu-toggle-wrap">
									<div class="mobile-menu-right"><ul class="header-wrap-right">
																						
															                        </ul></div>
									<div class="hamburger-menu">
										<button type="button" class="menu-toggle">
											<div class="top-bun"></div>
											<div class="meat"></div>
											<div class="bottom-bun"></div>
										</button>
									</div>
								</div>
								<div id="mobile-m" class="mobile-menu">
									<button type="button" class="header-close-menu close-style"></button>
								<ul id="menu-header" class="menu-wrap"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-38 nav-item"><a title="About us" href="https://gotmework.com/about-us/" class="nav-link">About us</a></li>
</ul></div>
							</div>
						</div>
					</div>
				</div>        
		    </div>
    		<div class="nav-area d-none d-lg-block">
		        <div class="navbar-area sticky-nav">
		            <div class="container">
		                <div class="row">
		                    <div class="col-lg-3 col-6 my-auto">
		                        <div class="logo">
		                            <a href="#">
										 </a><a href="https://gotmework.com/" class="custom-logo-link" rel="home" aria-current="page"><img width="1948" height="583" src="https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1.png" class="custom-logo" alt="Got Work" srcset="https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1.png 1948w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-300x90.png 300w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-1024x306.png 1024w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-768x230.png 768w, https://gotmework.com/wp-content/uploads/2020/09/cropped-gotWorkLogoGreyOrange-1-1536x460.png 1536w" sizes="(max-width: 1948px) 100vw, 1948px"></a>																						<p class="site-description">Experts around the middle east</p>
																			
		                        </div>
		                    </div>
		                    <div class="col-lg-9 my-auto">
		                    	<div class="theme-menu">
			                        <nav class="menubar">
			                            <ul id="menu-header" class="menu-wrap"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-38" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-38 nav-item"><a title="About us" href="https://gotmework.com/about-us/" class="nav-link">About us</a></li>
</ul>			                        </nav>	
			                        <div class="menu-right">			
				                        <ul class="header-wrap-right">
																						
															                        </ul>
				                    </div>
			                    </div>
		                    </div>
						</div>
			        </div>
		        </div>
		    </div>
	    </div>
    </header>